document.getElementById("userregistration").addEventListener('submit', function(e) {
    e.preventDefault();

    const user = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        password: document.getElementById('password').value  // fixed spelling
    };

    fakeAjaxPost('/register', user, function(response) {
        if (response.status == 'success') {
            let users = JSON.parse(localStorage.getItem('users')) || [];
            users.push(user);
            localStorage.setItem('users', JSON.stringify(users));

            window.location.href = 'list.html';
        }
    });
});

function fakeAjaxPost(url, data, callback) {
    console.log("Posting to", url);
    console.log("Data:", data);
    setTimeout(() => callback({ status: 'success' }), 500);
}
